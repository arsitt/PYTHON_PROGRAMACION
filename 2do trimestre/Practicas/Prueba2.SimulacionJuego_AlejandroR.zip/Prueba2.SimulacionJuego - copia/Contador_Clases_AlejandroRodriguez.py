class Juego():
    
    def __init__(self):
        self.__jugador1 = input(str("Introduce tu nombre: "))
        self.__jugador2 = input(str("Introduce a tu oponente: "))
        




juego1 = Juego("Alberto")

juego1.num_jugadores()


    